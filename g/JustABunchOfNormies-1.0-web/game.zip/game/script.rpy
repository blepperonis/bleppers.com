# The script of the game goes in this file.

# Declare FUNKtions //does a dance

define flipPos = 1 #flip is false by default bc y would it not be?
define slide = "none"

# Declare other variables I guess

default jProfile = 0
default hProfile = 0

default goodBoyPoints = 0

default hollyScore = 0
default jonnyScore = 0
default milkScore = 2
default creamScore = 0

# Declare characters used by this game. The color argument colorizes the
# name of the character.

define nar = nvl_narrator
define everyone = Character("EVERYONE")

define c = Character("CHIP", color="#a96645")
define cr = Character("CREAM", color="#33b96c")
define h = Character("HOLLY", color="#403939")
define j = Character("JONNY")
define m = Character("MILK", color="a543a5")

define t = Character("TEACHER")

#define menu = nvl_menu

# Character Images

image jonny neutral = "images/characters/jonny/jonny_neutral.png"
image jonny surprised = "images/characters/jonny/jonny_surprised.png"
image jonny happy = "images/characters/jonny/jonny_happy.png"
image jonny confused = "images/characters/jonny/jonny_confused.png"

image chip neutral = "images/characters/chip/chip_neutral.png"
image chip surprised = "images/characters/chip/chip_surprised.png"
image chip happy = "images/characters/chip/chip_happy.png"
image chip confused = "images/characters/chip/chip_confused.png"
image chip resting = "images/characters/chip/chip_resting.png"
image chip sleeping = "images/characters/chip/chip_sleeping.png"

image milk neutral = "images/characters/milk/milk_neutral.png"
image milk surprised = "images/characters/milk/milk_surprised.png"
image milk happy = "images/characters/milk/milk_happy.png"
image milk confused = "images/characters/milk/milk_confused.png"
image milk bored = "images/characters/milk/milk_bored.png"

image holly neutral = "images/characters/holly/holly_neutral.png"
image holly surprised = "images/characters/holly/holly_surprised.png"
image holly happy = "images/characters/holly/holly_happy.png"
image holly confused = "images/characters/holly/holly_confused.png"
image holly happy pyjamas = "images/characters/holly/holly_confused.png"

image cream neutral = "images/characters/cream/cream_neutral.png"
image cream happy = "images/characters/cream/cream_happy.png"
image cream surprised = "images/characters/cream/cream_surprised.png"
image cream confused = "images/characters/cream/cream_confused.png"
image cream bored = "images/characters/cream/cream_bored.png"
image cream angry = "images/characters/cream/cream_angry.png"

# ----- misc characters start here

image teacher neutral = "images/characters/misc/teacher_neutral.png"

# animations?

image milk upset:
    "milk surprised"
    pause 0.5
    "milk bored"
    pause 0.5
    "milk surprised"
    pause 0.5
    "milk confused"
    pause 0.5

init python:

    #scene + bg stuff
    def set_bg(bg_name):
        renpy.scene()
        renpy.show(bg_name)
        renpy.with_statement(fade)

    #this doesn't clear the screen
    def set_bg_only(bg_name):
        renpy.show(bg_name)

transform leftside:
    on show:
        xzoom -1
        xpos 200
        alpha 0.0
        linear 1.0 alpha 1.0
    on hide:
        linear 1.0 alpha 0.0

transform rightside:
    on show:
        xpos 800
        alpha 0.0
        linear 1.0 alpha 1.0
    on hide:
        linear 1.0 alpha 0.0


# The game starts here.

label start:

menu (nvl=True):

    #nar "To begin, select from the following:"

    "Start from Scene 1 (the beginning)":
        nvl clear
        jump scene_1
    "Start from Scene 2":
        nvl clear
        jump scene_2
    # "Start from Scene 3":
    #     nvl clear
    #     jump scene_3

    # "Play as ____":
    #     pass

###################################################
# Chip
###################################################

#label chip:

label scene_1:

    # Show a background. This uses a placeholder by default, but you can
    # add a file (named either "bg room.png" or "bg room.jpg") to the
    # images directory to show it.

    $ set_bg("chips_room_night")

    "His brows furrow at the sudden sounds of an alarm going off on his phone."

    "Barely any more alert, his hand lurches out from under the blanket as he fumbles and swipes at his phone's screen, looking for the dismiss option but missing it entirely."

    c "...Please ...Stop."

    "A groan escapes his lips as he pleads at the blaring inanimate object's literal siren song."

    "Suddnenly the music (if he could call it that) subsides.
    \nSuccess, yet he feels no relief."

    c "...So early ...I don't wanna get up..."

    $ set_bg_only("bg_chips_phone")

    "Chip looks at his phone's clock. 5:45 am."

    $ set_bg("chips_room")

    "He gets up."

    "It often takes him a few minutes to adjust to standing up and to get the sense of tiredness from out of his system so as to not pass out again. Today is no different."

    "As always, his morning routine is uneventful but full of activity.
    \nHe wakes up an hour earlier than needed, just to make sure everything is...In place."


    $ set_bg("bg_jonny_knocking")

    "Though he's less in a mood once he leaves the house, he nearly jumps when an unexpected but familiar figure meets him at the door, fist raised as if to knock on the now swung open door."

    $ set_bg("chips_house")

    show jonny neutral with dissolve

    # These display lines of dialogue.

    j "Wow, look at this. It's sorta surreal."
    j "With how much you sleep, I didn't think you'd be up so early."

    # $ jProfile == 1
    # "(Jonny's profile unlocked)"

    c "This is embarrassing."

    show jonny neutral:
        xzoom -1
        xpos 300

    show chip neutral with dissolve

    j "You don't look embarrassed."
    c "I'm...Tired and incapable of expressing anything but mildly annoyed at the moment."
    j "I wonder how many people we can cram in all at once."
    c "Who knows..."

    c "Ah, I see Milk and Holly... *yawn*"

    show jonny neutral
    show chip neutral:
        xzoom -1
        xpos 400

    show holly neutral at rightside with dissolve
    show milk neutral with dissolve:
        xpos 500

    m "Halloooo~\n\no 3o"

    c "Hey."

    show milk surprised

    m "O 3O"

    show milk:
        xpos 600

    show chip confused

    c "Uh..."
    h "Hey, guys. What are you up to?"
    j "Just wondering what's going on, that's all."
    j "Where's Cream?"

    show milk bored

    m "Sleeping in again. = 3= I tried to wake her up, but she just ignored me."

    j "Sounds like her."
    c "Yeah...But..."

    show jonny surprised
    show chip resting

    c "I sorta get her... And..."

    show chip resting

    show chip sleeping
    c "Hnn...\nZzzzz..."

    $ set_bg("bg_chip_sleeping")

    m "Eeek!!"
    j "Welp. Looks like we lost another one."
    j "Guess I'll drag him to first period."

    "END SCENE 1"

####################################
label school:
####################################
    $ set_bg("inside")

    show jonny neutral at leftside

    show milk neutral with dissolve

    show holly neutral at rightside

    j "He's a loose one."
    h "..."

    show holly confused

    h "Excuse me?"
    j "I meant like a cat."

    show jonny confused

    j "You know how some of them just sorta...
    \nHang limp when you hold them?"
    j "Not all of them, of course, but my aunt's got a cat that kinda goes limp when you carry her.
    \nLike, carry-them-over-your-shoulder kinda limp."

    show jonny happy

    j "I mean, most cats tense up when you hold them, but I guess since she's really friendly and let's everyone carry her and all, she doesn't do that."
    j "He's kinda like that, in a way. Just more heavy."

    show jonny confused

    j "I dunno if Chip would just let anyone carry him though.
    \nHe's not exactly light either. Like I'm not even sure you or Milk could even hold him up for a few seconds."
    j "But yeah, that's what I mean. He's like a cat."

    show jonny neutral

    j "...I think? Yeah."

    "Holly squints at him before shaking her head."

    h "...Like, my dude. I'm getting you a coffee from the caf."

    show jonny surprised

    j "Huh? Why?"
    h "Just wait here, I'll be back in a few."

    show jonny neutral

    hide holly neutral with dissolve

    m "Oh my."
    j "We got a few minutes to kill.
    \nLet me just prop your buddy up in a chair..."
    m "o 3o Why don't you just wake him up??"
    j "Ah. That makes more sense.
    \nGive me a few."

    hide jonny neutral

    pause 2

    "*LIGHT SWATTING NOISES*"

    show milk confused

    m "UWAH!! Don't slap his cheeks!!"

    show jonny neutral at leftside

    j "Wow, this guy really doesn't get up, huh?
    \nFine, you do it."

    show milk surprised

    m "...o 3o Actually I just sort of watch him until he wakes up."
    j "..."

    show jonny confused

    j "Maybe I'll just give him the coffee Holly's bringing."

    "*SUDDEN SQUEAKY SOUNDS OF RUBBERY SHOES AGAINST TILE*"

    cr "BIG WAH! I'M HERE!"

    show cream neutral at rightside
    show jonny surprised

    cr "What the heck. Did Chip trip or something?"

    show jonny confused

    j "Nah, just fell asleep again.
    \nDude really needs to go to a doctor about this."

    show milk confused

    m "I think it's cute!!"
    j "..."

    show cream confused

    cr "..."
    cr "Milky, he could be suffering from a medical issue."
    m "..."

    show milk surprised

    m "O 3O..."
    m "OH NO, CHIP IS SICK!"
    j "Wait, that's not-"

    "The class teacher arrives and sees the commotion.\nHolly, with a coffee in hand, is right behind him."

    show teacher neutral with dissolve:
        xpos 700

    show holly neutral at rightside

    hide milk
    show milk surprised with dissolve:
        xpos 300
    show cream neutral with dissolve:
        xpos 400

    t "What's happening this time?"

    "He looks down."

    t "Again?"

    show cream bored

    cr "Again."

    show milk bored

    m "Mmhmm."
    j "Looks like it."

    show holly confused

    h "I should've gotten a large coffee."

    show jonny neutral

    j "Thanks, by the way."

    h "I meant for me."

    t "Well, you better wake him up. He's blocking the door."

    show jonny happy

    j "Eyooo, I got you, fam."

    hide jonny

    "*DRAGGING OFF NOISES*"

    t "Why do young people say such strange phrases?"

    hide teacher with dissolve
    show milk surprised

    m "UWAH! Don't drag him by the jacket!!"

    j "Chill. He's not gonna get up anyway."

    hide milk with dissolve

    h "..."
    h "Here we go again."

    hide holly

    cr "..."

    show cream surprised

    cr "Wait...WHAT! I'm LOST!"

    hide cream with fade

    "END SCENE 2"

####################################
label scene_2:
####################################

    $ set_bg("outside_school")

    show cream neutral with dissolve:
        xpos 600

    show holly neutral at rightside
    show jonny confused at leftside

    show chip neutral with dissolve:
        xpos 400

    show milk neutral with dissolve:
        xpos 500

    j "Well, it's the weekend."

    show holly confused

    h "You don't sound very excited."
    j "It's just the same thing every weekend, though.
    \nNothing to do but waste time."

    show chip confused

    c "Huh?...Don't you guys have homework?"

    "Holly and Jonny look at each other for a moment and pause."

    show jonny happy
    show holly happy

    j "Nope. Done." (multiple=2)
    h "Finished it." (multiple=2)

    show milk bored

    m "Ooh~ That's lucky.
    \nI, um, have lotsa math to work through..."

    show chip neutral

    c "Ah, same."

    show milk surprised

    m "... o 3o"

    show chip confused

    c "...??"

    hide cream
    show cream angry with dissolve:
        xpos 600

    cr "I GOTTA WRITE A PAPER!"

    show jonny neutral

    j "Good luck with that, I'm gonna be playing games all weekend again."
    c "You...Play games?"
    j "Yeah, man. Why?"
    c "...I..."

    show chip neutral

    c "Can I play with you?"

    show jonny happy

    j "Sure, what kinda games do you play-"

    show milk confused

    m "BUT OUR MATH HOMEWORK!"


    c "...Should only take us a few hours."

    show milk confused

    m "o 3o... = 3=... o 3o... > 3<"

    show holly confused
    show jonny confused
    show chip surprised
    show cream bored

    h "You're upsetting him."

    c "...Huh?"
    m "You...
    \nYou dumb dumb!!"

    hide milk with dissolve

    cr "Booooy, you in trouble..."

    hide cream with dissolve
    show chip confused

    c "What did I even do this time?
    \nI... I'm too tired... To deal with this..."
    j "Uh, yeah, when you finish text me. See ya."

    hide jonny

    h "Oh, boy."

    show holly neutral:
        xpos 600

    h "...Walk me home?"
    c "...Uh? Sure...?"

    show holly confused

    h "Sorry, parents get all worried when I come home by myself and Jonny ditched us, soooo..."
    c "Right, I got you..."

    $set_bg("outside")

    "A few minutes pass in silence as they walk."

    show chip neutral at leftside
    show holly neutral at rightside

    h "..."
    h "Anyway, what's up with the whole 'sleepy thing'?"
    c "'Sleepy thing'?"
    h "Yeah! You, like, pass out all the time. Everyday. But no one bats an eye, right? Not even the adults?"

    show chip happy

    "Chip almost chuckles."

    c "Must not 'cause of my grades. But I dunno...I'm just tired."
    h "For no reason?"

    "He thinks about it but can't think of any reason."

    show chip neutral

    c "I...I guess. I don't know why I'd be tired."

    "Holly stops walking."

    h "Dude, you should see a doctor. It could be serious."
    c "I'm alright, really. Just...Need to rest."
    h "Uh huh."

    "She clearly does not believe him."

    h "I mean, I can't force you, but you should really go see a doctor, just once, to make sure. Imagine getting into an accident by passing out on the street. I have no idea how you keep straight As."

    menu:
        c "(Urgh, I really don't wanna get into this...What should I tell her...?)"

        "I'm fine, 'mom'.":
            h "Okay, whatever. I'm just worried."
            $ hollyScore -= 1
            "(Score with Holly: [hollyScore])"

        "I'll talk to my parents about it...":
            h "That's good enough, I guess. I'm just worried about you."
            "(Score with Holly: [hollyScore])"

        "I'll go when I can...":
            h "Please. Just make sure it's not a medical issue, okay?"
            "(Score with Holly: [hollyScore])"

label holly_continue:

    $ set_bg("hollys_house")

    "They arrive at Holly's house."

    show chip neutral at leftside
    show holly neutral at rightside

    h "Thanks, see you tomorrow."
    c "T...Tomorrow?"
    h "Yeah, you're going to Jonny's, right? To play games or whatever? I'll join."
    c "Um, uh, okay...I mean, we didn't make plans or anything..."
    h "It's cool, just text him whatever, whenever. I know his weekends pretty well and trust me, he'll appreciate the company."

    "She's about to enter before she turns around."

    h "Oh, and another thing..."

    show chip surprised

    c "Y-Yeah...?"

    show holly happy

    h "Invite Milk and Cream over too. Jonny's got a huge couch."
    h "'Kay, bye."

    hide holly

    "END SCENE 3"

label scene_3:

####################################
label chips_room_main:
####################################

    $ set_bg("chips_room")

    c "Finally home..."

    menu:
        "How to end the day...?"

        "Do homework (all)":
            c "Might as well finish it..."
            "..."
            "..."
            c "Done."

            $ goodBoyPoints += 1
            "(Total 'Good boy points': [goodBoyPoints])"
            jump sleep

        "Just relax.":
            jump sleep

label sleep:
    c "My...Element... Zzzz..."


## remove me ==============================

jump final_end

####################################
label scene_4:
####################################

    "SCENE 4"

    $ set_bg("jonnys_house")

    c "..."

    show chip surprised with dissolve

    c "This is the right house, right...?"

    "The door creaks open. Jonny is in his jammies."

    hide chip
    show chip surprised at leftside
    show jonny neutral at rightside

    j "Nice, you made it. You didn't text me, though...?"

    show chip neutral

    c "Oh, right. Sorry."
    j "It's cool. Holly pretty much told me everything this morning."

    show jonny confused

    j "Where are the twins?"
    c "Oh, right. Sorry. Again."

    show jonny neutral

    j "Nah, it's good. I'll give them a call. Why don't you come in?"
    c "Thanks..."

    hide jonny
    hide chip

# inside jonny's house

    "Chip carefully steps inside."

    "If he thought it was big from the ouside, it was only confirmed when Chip pokes his head through the front door and closed the door behind him."

    "Despite all the furniture, there's a slight echo when he moves.\n(Must be the high ceilings.)"

    "DING DONG!"

    show jonny surprised at rightside:

    j "Wow, that was quick."

    show chip neutral at rightside:
        xpos 600

    show cream neutral at leftside

    cr "I'M HERE!"
    cr "Oh, and Milky too."

    show jonny confused

    j "Yeah, I heard you scream 'DING DONG' from outside. Can you not be so loud? It's like dealing with a literal child."
    cr "Oops. I got excited seeing this HUGE HOUSE, WAHHHHH!"

    show cream angry

    cr "Also, I was calling you a ding-dong, you ding-dong!"

    show chip happy

    c "*snort*"

    show milk neutral at leftside:
        xpos 100

    m "Um, excuse her. Thank you for inviting us, Jon-"

    show milk surprised

    m "-CHIP IS HERE!!"

    show chip resting

    c "...My head."

    j "Alright guys. Let's just get inside."

    "Chip nearly stumbles while getting his shoes off as the twins push into the door behind him."

    hide cream
    hide milk
    hide jonny

    "Once he's settled, feet  Chip looks around again. \nHe had never really been to people's houses before and when he had, never one so big."

    show chip surprised

    "He's in awe for so long that when turns to look at Jonny again he finds no one is around."

    j "Yo, Chip! In here!"

    "While the voice leads him, only the faint smell of coffee actually tells him where he's going."

    $set_bg("bg_jonnys_kitchen_group")

    "..."

    c "Why is it...So...Massive?"

    $ set_bg_only("bg_jonnys_kitchen_twins")

    show chip neutral at rightside
    show jonny neutral at leftside

    j "What? I mean, I dunno. Have a coffee or something, you're always so out of it, man."
    c "Er, um...I already...Had one."

#

    j "Oof, okay then. Why don't you just head to my basement?"
    c "Huh?"
    j "You know, the game room? I got all sorts of cool shit down there."
    cr "Mmhmm, that's what they all say. I suggest you watch your booty around Jonny, Chip."

    show chip confused
    show jonny surprised

    c "Huh??" (multiple=2)
    j "What??" (multiple=2)

    show milk bored

    m "CREAM! Um...I'll go with you if you're scared, Chip~♫ ♥♥♥"
    c "...Yeah, alright. Let's just go already..."

    "Down the basement~"

    "SCENE 5"

####################################
label basement:
####################################

    $set_bg("jonnys_basement")

    m "Uwah, wow! He wasn't lying. It's, like, retro!\nI love all the wood panelling."
    c "...Yeah. It's...Nice, actually."
    m "Hmm?? Do you like arcade-y thingies, Chip? o 3o"
    c "Mm...Yeah. Maybe more the idea of them, though."
    m "Ooh, I see. You're super smart and into computer thingies, so I totally understand."

    "Milk picks up a controller."

    m "...It's heavy! > 3<"

    "Chip plucks the controller from the other boy's hands."

    c "Huh. It's...Got some heft, yeah."

    "A blonde blur snatches it from him, raising it above her head triumphantly.\nJonny rushes forward when he sees the wire straining."

    show cream neutral at rightside

    cr "It feels powerful in my hands!!"
    j "In your hands it's more like deadly."

    show jonny confused at leftside

    "Jonny swipes the controller from the girl who squawks in objection."

    h "Uh, hello to everyone too!"

    show holly neutral with dissolve

    "Holly waves from the couch before sipping from a mug of something sweet smelling in one hand, and munching on a cracker in the other."

    cr "Wah, Holly~ I love your pyjamallamas. Tres chic."

    show holly happy

    h "Thanks! I found these inside an old box in my room. They're stupid comfy."

    hide jonny
    hide holly
    hide cream
    hide chip
    hide milk

    "There's a shuffling of cables."



    j "So...I gotta bunch of things plugged into the power bar. Can't touch the <console>, though, or Justin is gonna be piiiiiissed."
    h "Justin is a dick, and I don't like him."
    j "Absolutely."
    j "Anywaaaaays... Whatcha guys wanna play?"

    m "I dunno! I just wanna watch. o 3o"
    c "I-"
    cr "Can we pleeeeease play a beat-em-up I wanna PUNCH AND KICK THINGIES in a video game."
    c "I wouldn't mind tha-"
    j "What? I don't really want to replay '' when I have a backlog of other stuff."
    c "Well...Maybe we coul-"
    cr "WOW, why are you so rude?? LIKE BIG RUDE. I didn't even say which game I want to play."
    c "...You know, let's-"
    j "'Cause I know you and what you like."
    cr "I LIKE A LOT OF THINGIES, YOU DING-DONG."
    h "'Ding-dong?'"
    c "...So lou-"
    h "Oh my god, Cream. Did you just call Jonny a 'Ding-dong'? That's so stupid that it's hilarious!"

    m "CHIP IS TRYING TO TALK!! O ^O"

    j "...Sorry." (multiple=2)
    cr "...Oopsie." (multiple=2)

    h "..."
    h "Oh! Yeah, sorry. Pretend I didn't say anything."
    c "I just wanted play something like..."

    menu:
        "A platformer.":
            $ hollyScore -= 1
            $ jonnyScore += 1
            h "Ugh. Really?"
            j "No, it'll be good. Watch him ragequit!"

        "A party game.":
            $ hollyScore += 1
            $ milkScore += 1
            h "Oh, sounds fun! Can I join?"
            m "Me too!!"

        "A competitive game.":
            $ creamScore += 1
            cr "I gonna beat all of you up!!"
            j "Like you don't already try that everyday."
            cr "Okie, Jonny, you know WHAT-"
            h "Oh-kaaaay, you two need to settle down."

        "A horror game.":
            $ milkScore -= 1
            $ creamScore += 1
            $ jonnyScore += 1

            j "Odd choice, but I kinda wanna see you get spooked."
            m "...I don't wanna look then..."
            cr "It's okie, you can hide under this blanket."

label game_select:

    " (Score with Holly: [hollyScore])\n
    (Score with Jonny: [jonnyScore])\n
    (Score with Milk: [milkScore])\n
    (Score with Cream: [creamScore])\n"

    cr "Yah, okie. Let's play what Mr. Sleeping Booty wants."
    c "Wait, what did you just call-"

    m "Oh my." (multiple=2)
    h "Woohoo!" (multiple=2)


    "It takes a while but Chip "

    j "Wow, how long was that?"
    c "A...Few...Hours?"

    show jonny happy at rightside

    "Jonny laughs at that."

    h "Yeah! I'm pretty beat, actually."
    m "My eyes burn o 3o"
    cr "More games!! I WANNA PLAY MORE!! I don't wanna go home tee-bee-aych."

    menu:
        "(To Jonny) Thanks for inviting me, man.":
            j "Yeah! You wanna stay over?"
            jump stay_leave

        "(To Holly) You're pretty good.":
            h "Haha! Bet you didn't expect such skill from me, did you?"
            c "Never doubted you..."
            jump go_home

        "(To Milk) You learn fast!":
            jump go_home
        "(To Cream) How are you so good at so many games?":
            jump go_home


label stay_leave:

    menu:
        "Yeah, sure, I'll stay over.":
            jump stay_over
        "No, I should be getting home...":
            jump go_home


label stay_over:

    c "I have to call my parents first though!"
    j "Nice. You do that while I let my parents know."

    hide jonny
    show holly neutral with dissolve

    h "You staying over too?"
    c "'Too'?"
    h "Yup. I'm staying over."
    c "...Your mom and dad let you do that?"
    h "Uh huh. We're, like, family friends. They trust me. And him."
    h "Buuuut since they don't really know you I won't mention that you're here too. No offense."
    c "No. I get it."
    h "..."

    "Holly looks behhnd her, looking worried, and Chip isn't sure what to think of it before she scoots closer."

    show holly confused

    h "How are you feeling? ...Did you talk with them?"

    "Her voice is nearly a whisper. It's soft but Chip sighs. Not this again."

    c "I'm fine, Holly. Really."

    "It wasn't a lie."

    h "Okay. I just... I'm sorry. I don't mean to nag."
    c "It's fine. I'm not upset or anything."

    show holly neutral

    h "Hmm. Okay. I'm okay if you're okay."
    c "I am. Thanks, Holly."

    j "Am I interrupting something here or...?"
    h "Not interrupting. We were just done talking."
    c "...Um... Yeah..."

    j "Oh-kay then."

    "Jonny saunters over and nudges himself between the two."

    j "Talked to dad. He says it's fine."
    h "Your dad?"
    j "Mmhmm. Dad. It's all good."
    h "Really."
    j "Yeah. One condition though, Chip."
    c "...Sure?"
    j "You okay with sleeping in the basement?"

    "Chip snorted. The basement is bigger than his bedroom and living room combined. He definitely wouldn't mind."

    h "Ohhh, we're all gonna have to say in the basement then."

    "The look of realization on Holly's face makes Chip raise a brow and Jonny smile sheepishly."

    h "Wait, no. Then our normal arrangment won't work then?"
    c "...What arrangement?"
    j  "I take the couch and Holly takes the guest bedroom."
    h "Are you going to sleep upstairs then?"
    j "Well...No. Uh, we gotta work with what we have down here."
    h "You're kidding."
    j "Nope."

    j "So, Chip, since you're the new guest here, what do you think?
    \nWe've got a few options here."
    j "Holly can take the guest bedroom as usual and you can take the couch.
    \nThat means I'll have to sleep on the floor but it could be worse."
    j "Or, you and I can cram ourselves onto the bed in the guest bedroom, and Holly can have the big comfy couch all to herself."
    h "Oh, I like that option."
    j "Ooor...
    \nI mean...If she's okay with it..."
    h "...Go on."
    j "You and Holly can share the guest bed and I can lie down on this here couch."
    h "Hmm. Okay."
    c "Why don't you guys share the bed?"
    j "Sure, that's an option too."
    j "Finally, you guys could also try the floor if you really wanted to.
    \nIt's not that dusty but it is sort of cramped, between all the furniture and stuff."

menu:
    j "What do you think?"

    "I'll take the couch. You guys can share the bed.":
        jump couch
    "I'll take the couch. Holly can have the guest bed.":
        jump couch_j
    "Holly can take the couch. We can fit on a double bed, no problem!":
        jump share_j
    "You can have the couch. Holly and I can share the bed.":
        jump share_h
    "I belong on the floor...":
        jump floor

label couch:
    j "You sure?"
    c "Yeah. I mean...I'm not really..."
    j "It's alright."
    jump go_home

label couch_j:
    j "Sure, I'll take the nice hard wood floor."
    c "Dude, I-"
    j "You want me around, it's cool."
    h "Okay, guys. I'm going to brush my teeth now."
    jump go_home

label share_j:
    j "..."
    j "Kinda didn't think you'd pick that option."
    c "I.. It's your house, if you don't feel comfortable..."
    j "I got plenty of blankets to divide us, don't worry about it."
    h "You're not gonna get germs from slightly brushing up against each other."
    c "It's the principle, Holly..."
    j "...Extra blankets!"
    h "Whatever, guys. I'm going to brush my teeth now."
    jump go_home

label share_h:
    j "Fair enough."
    h "I just hope you don't move around a lot in your sleep."
    c "I'm a rather... Heavy sleeper. So I don't move much at all..."
    h ""
    jump go_home

label floor:
    j "Aww."
    h "Chip..."
    c "It's fine..."
    j "Are you sure?"
    c "...Yeah. You can take the couch."
    jump go_home

label go_home:

    j "Alright, that's cool. See ya on Monday."

    $set_bg("chips_room")

    c "Well, back home... What now?"


###################################################
# Jonny
###################################################


    # This ends the game.
label final_end:
    return
